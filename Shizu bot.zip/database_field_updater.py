# Script solamente para updatear/agregar valores en la base de datos una sola vez

import discord
import random
import inspect
from shizu_plugins import ShizuPlugin
from bot_vars import *
from ctypes.util import find_library
from shizu_tasks import *
#from commands import Commands
import asyncio
import Debug
import time
from shizu_database import ShizuDatabase
from core import debug_log

class Shizu(discord.Client):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.owner_channel = None
        self.database = ShizuDatabase()

    def run(self, *args, **kwargs):
        self.loop.run_until_complete(self.start(*args, **kwargs))

    async def on_ready(self):
        for guild in self.guilds:
            for member in guild.members:
                #print("miembro %s guardado" % member.name)
                bot_vars.DEBUG = True
                self.database.add_field({"_id" : member.id}, "members", {"last_message_time" : 0})

while (True):
    try:
        print("iniciando shizu")
        shizu = Shizu()
        shizu.run(TOKEN)
    except Exception as e:
        print("Me rompi")
        with open('errorlog.txt', 'a+') as error_log:
            error_log.write("[datetime.now().__str__()] " + e)
        time.sleep(5000)