# shizubot 

              ______ ______ ______ ______ ______ ______ ______ ______ ______
             |______|______|______|______|______|______|______|______|______|
              ______ ______ ______ ______ ______ ______ ______ ______ ______
             |______|______|______|______|______|______|______|______|______|
              / ____| |   (_)                              | |     | | |
             | (___ | |__  _ _____   _   _ __ ___  __ _  __| |_   _| | |
              \___ \| '_ \| |_  / | | | | '__/ _ \/ _` |/ _` | | | | | |
              ____) | | | | |/ /| |_| | | | |  __/ (_| | (_| | |_| |_|_|
             |_____/|_| |_|_/___|\__,_| |_|  \___|\__,_|\__,_|\__, (_|_)
                                                               __/ |
              ______ ______ ______ ______ ______ ______ ______|___/__ ______
             |______|______|______|______|______|______|______|______|______|
              ______ ______ ______ ______ ______ ______ ______ ______ ______
             |______|______|______|______|______|______|______|______|______|
             
A personal discord bot

Dependences:
- [youtube-dl](https://github.com/ytdl-org/youtube-dl)
- [requests](https://github.com/psf/requests)
- [mongodb](https://www.mongodb.com/es)
- [pymongo](https://github.com/mongodb/mongo-python-driver)
- [discord.py and voice dependences](https://github.com/Rapptz/discord.py)
- [Pillow](https://github.com/python-pillow/Pillow)
- [aiohttp with speedups](https://docs.aiohttp.org/en/stable/)