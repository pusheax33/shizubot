﻿"""
    Configuraciones y variables que usara el bot.

"""

SHIZU_VERSION = "2.0"

#  ======================================== SHIZU CONFIG VARIABLES ========================================
TOKEN = "MjE3MDc3NTY3MzMxNjMxMTE2.XTee6A.E6WbF9xEc_vJ2KBM7FmeVtTNNAI"
CHIZU_TOKEN = "NjkzOTMzMjQ5NDM2NTgxOTgw.XoER1Q.2Qpcwc6TgiL37qc_SCl_UjQD8FU"
SHIZUWEB = "3.23.87.87"
COMMAND_PREFIX = "!"
DEV_ID = 519700955344797696  # El ID del dueño del bot
BOT_ID = 217077567331631116
OWNER_SERVER_ID = 217061515189026817
OWNER_SERVER_CHANNEL = 578442520665522186
DEBUG = True
DEBUG_MESSAGE_FILTER = "ALL"
GITHUB_URL = ""
BING_API_KEY = "518e8429894447e4ad3c449e7cba1fcc"
BING_ENDPOINT = "https://shizu.cognitiveservices.azure.com/bing/v7.0"

#  ======================================== SHIZU LINKS VARIABLES ========================================
SERVER_INVITE_LINK = "https://discord.gg/NsR7mAV"
SHIZU_INVITE_LINK = "https://discordapp.com/api/oauth2/authorize?client_id=217077567331631116&scope=bot&permissions=0"

#  ======================================== SHIZU FOLDERS VARIABLES ========================================
IMG_FOLDER = "assets/images/"
IMG_SHIZU_FOLDER = "assets/images/shizu/"
IMG_MEMES_FOLDER = "assets/images/memes/"
FONT_FOLDER = "assets/fonts/"
TEMP_FOLDER = "temp/"  # Carpeta contenedora de imagenes o archivos temporales que se eliminaran
UPDATE_FOLDER_NAME = "update_shizu"
